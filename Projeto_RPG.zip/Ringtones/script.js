// ==============================
// ATALHOS DO SITE DE RECEITAS
// ==============================
const pesquisa = document.getElementById("pesquisa");
const botao = document.getElementById("botao-pesquisar");
const receitas = document.querySelectorAll(".receita");
const resultado = document.getElementById("resultado");
const botoesCategoria = document.querySelectorAll(".filtro-categoria");
const botoesReceita = document.querySelectorAll(".botao-receita");
const botoesFechar = document.querySelectorAll(".fechar-receita");

let categoriaAtual = "todas";

// ==============================
// SISTEMA DE TELAS DA ORDO
// ==============================
// Lista com TODAS as telas da Ordo.
// Pra adicionar uma tela nova, só colocar o ID aqui.
const telasOrdo = [
    "tela-analise",
    "tela-ordo",
    "central-comunicacao",
    "confirmacao-agente",
    "dossie-agente",
];

// Esconde todas e mostra só a que você quer
function mostrarTela(idTela) {
    telasOrdo.forEach(function (id) {
        const tela = document.getElementById(id);
        if (tela) tela.hidden = (id !== idTela);
    });
}

// Esconde todas as telas da Ordo
function esconderTodasTelasOrdo() {
    telasOrdo.forEach(function (id) {
        const tela = document.getElementById(id);
        if (tela) tela.hidden = true;
    });
}

// ==============================
// FILTRO DE RECEITAS
// ==============================
function filtrarReceitas() {
    const termo = pesquisa.value.toLowerCase();

    // Palavra mágica: "ordo realitas"
        if (termo.trim() === "ordo realitas") {
           document.querySelector("header").hidden = true;
           document.querySelector("main").hidden = true;
           iniciarAnalise(); // <-- em vez de mostrarTela("tela-ordo")
           return;
}

    let encontradas = 0;

    receitas.forEach(function (receita) {
        const texto = receita.textContent.toLowerCase();
        const categoria = receita.dataset.categoria;

        const combinaTexto = texto.includes(termo);
        const combinaCategoria =
            categoriaAtual === "todas" || categoria === categoriaAtual;

        if (combinaTexto && combinaCategoria) {
            receita.style.display = "block";
            encontradas++;
        } else {
            receita.style.display = "none";
        }
    });

    if (encontradas === 0) {
        resultado.textContent = "Nenhuma receita encontrada.";
    } else {
        resultado.textContent = encontradas + " receita(s) encontrada(s).";
    }
}

botao.addEventListener("click", filtrarReceitas);

botoesCategoria.forEach(function (botaoCategoria) {
    botaoCategoria.addEventListener("click", function () {
        categoriaAtual = botaoCategoria.dataset.categoria;
        filtrarReceitas();
    });
});

// ==============================
// ABRIR / FECHAR RECEITA
// ==============================
botoesReceita.forEach(function (btn) {
    btn.addEventListener("click", function () {
        const detalhes = btn.nextElementSibling;
        detalhes.hidden = false;
        btn.textContent = "Receita aberta";
    });
});

botoesFechar.forEach(function (btn) {
    btn.addEventListener("click", function () {
        const detalhes = btn.parentElement;
        detalhes.hidden = true;
        const botaoAbrir = detalhes.previousElementSibling;
        botaoAbrir.textContent = "Ver receita";
    });
});

// ==============================
// AÇÕES DOS BOTÕES DA ORDO
// ==============================
// Mapa: "ID do botão" -> "função que ele executa"
const acoesBotoes = {
    // Voltar pra tela inicial da Ordo
    "voltar-inicio": function () {
        esconderTodasTelasOrdo();
        document.querySelector("header").hidden = false;
        document.querySelector("main").hidden = false;
        pesquisa.value = "";
        resultado.textContent = "";
        filtrarReceitas();
    },

    "acessar-comunicacao": function () {
        mostrarTela("central-comunicacao");
    },

    "voltar-ordo": function () {
        mostrarTela("tela-ordo");
    },

    "voltar-central": function () {
        mostrarTela("central-comunicacao");
    },

    "abrir-dossie": function () {
        mostrarTela("dossie-agente");
    },
};

// Registra todos os botões do mapa de uma vez
Object.entries(acoesBotoes).forEach(function ([id, acao]) {
    const btn = document.getElementById(id);
    if (btn) btn.addEventListener("click", acao);
});

// ==============================
// CONSULTAR AGENTE (campo especial)
// ==============================
const consultarAgente = document.getElementById("consultar-agente");

if (consultarAgente) {
    consultarAgente.addEventListener("click", function () {
        const numero = document
            .getElementById("numero-agente")
            .value.trim()
            .toUpperCase();

        const resultadoAgente = document.getElementById("resultado-agente");

        if (numero === "0724-OR") {
            resultadoAgente.textContent = "";
            mostrarTela("confirmacao-agente");
        } else {
            resultadoAgente.textContent =
                "IDENTIFICAÇÃO NÃO ENCONTRADA. Verifique o número informado.";
        }
    });
}

// ==============================
// EXTRA: permite apertar ENTER
// na pesquisa e no campo do agente
// ==============================
pesquisa.addEventListener("keydown", function (e) {
    if (e.key === "Enter") filtrarReceitas();
});

const campoAgente = document.getElementById("numero-agente");
if (campoAgente) {
    campoAgente.addEventListener("keydown", function (e) {
        if (e.key === "Enter") document.getElementById("consultar-agente").click();
    });
}

// ==============================
// TELA DE ANÁLISE IMERSIVA
// ==============================
const etapasAnalise = [
    {
        texto: "Verificando dispositivo...",
        itens: [
            { label: "DISPOSITIVO MÓVEL DETECTADO", status: "ok", valor: "✓" },
            { label: "SISTEMA OPERACIONAL", status: "ok", valor: "SEGURO" },
            { label: "GRAMPEAMENTO TELEFÔNICO", status: "ok", valor: "NÃO DETECTADO" },
        ],
    },
    {
        texto: "Analisando rede...",
        itens: [
            { label: "PROTOCOLO DE CRIPTOGRAFIA", status: "ok", valor: "AES-256" },
            { label: "VAZAMENTO DE DADOS", status: "ok", valor: "0%" },
            { label: "CONEXÃO SEGURA", status: "ok", valor: "ESTABELECIDA" },
        ],
    },
    {
        texto: "Captura biométrica em andamento...",
        itens: [
            { label: "ESCANEANDO IDENTIDADE VISUAL", status: "alerta", valor: "..." },
            { label: "RECONHECIMENTO FACIAL", status: "ok", valor: "COMPLETO" },
            { label: "REGISTRO ARQUIVADO", status: "ok", valor: "✓" },
        ],
        camera: true,
    },
    {
        texto: "Identidade reconhecida...",
        itens: [
            { label: "AGENTE IDENTIFICADO", status: "ok", valor: "0724-OR" },
            { label: "ACESSO AUTORIZADO", status: "ok", valor: "✓" },
            { label: "CONECTANDO À ORDO REALITAS", status: "alerta", valor: "..." },
        ],
    },
];

let analiseRodando = false;

function iniciarAnalise() {
    if (analiseRodando) return; // evita rodar 2x
    analiseRodando = true;

    mostrarTela("tela-analise");

    const simbolo = document.getElementById("analise-simbolo");
    const titulo = document.querySelector(".analise-titulo");
    const statusEl = document.getElementById("analise-status");
    const barra = document.getElementById("analise-barra");
    const lista = document.getElementById("analise-lista");
    const conteudo = document.querySelector(".analise-conteudo");

    // Reseta estado
    lista.innerHTML = "";
    statusEl.textContent = "Iniciando protocolo...";
    barra.style.width = "0%";
    simbolo.style.display = "";
    titulo.style.display = "";

    // Remove mira antiga (se houver)
    const miraAntiga = document.querySelector(".mira-camera");
    if (miraAntiga) miraAntiga.remove();

    let etapaAtual = 0;

    function rodarEtapa() {
        if (etapaAtual >= etapasAnalise.length) {
            // FIM → abre Ordo
            statusEl.textContent = "CONEXÃO ESTABELECIDA";
            barra.style.width = "100%";
            setTimeout(function () {
                analiseRodando = false;
                mostrarTela("tela-ordo");
            }, 1400);
            return;
        }

        const etapa = etapasAnalise[etapaAtual];

        statusEl.textContent = etapa.texto;

// Se for a etapa da câmera, mostra a "mira" (vazia)
if (etapa.camera) {
   const mira = document.createElement("div");
   mira.className = "mira-camera";
   // Dá um ID pra achar ela depois
   mira.id = "mira-foto";
   
   // Adiciona a mira na tela
   conteudo.insertBefore(mira, lista);
}

        // Adiciona os itens da etapa um por um
        etapa.itens.forEach(function (item, i) {
            setTimeout(function () {
                const li = document.createElement("li");
                li.innerHTML =
                    "<span>" + item.label + "</span>" +
                    "<span class='" + item.status + "'>" + item.valor + "</span>";
                lista.appendChild(li);

                // Se for o último item da etapa da câmera → FLASH!
                const ehUltimoItem =
                    etapa.camera && i === etapa.itens.length - 1;
                if (ehUltimoItem) {
                    dispararFlash();
                }
            }, i * 700);
        });

        // Atualiza a barra de progresso
        const progresso =
            ((etapaAtual + 1) / etapasAnalise.length) * 100;
        setTimeout(function () {
            barra.style.width = progresso + "%";
        }, 200);

        etapaAtual++;

        // Espera todos os itens da etapa aparecerem antes de ir pra próxima
        const tempoTotal =
            etapa.itens.length * 700 + 1000;

        setTimeout(function () {
            // Se era etapa da câmera, remove a mira
            const mira = document.querySelector(".mira-camera");
            if (mira) mira.remove();

            rodarEtapa();
        }, tempoTotal);
    }

    rodarEtapa();
}

function dispararFlash() {
    tocarSom('flash'); // <--- ADICIONE AQUI NO COMEÇO
    if (navigator.vibrate) navigator.vibrate([80, 40, 120]);

    const flash = document.createElement("div");
    flash.className = "flash-foto";
    document.body.appendChild(flash);

    // --- AQUI É ONDE A FOTO APARECE! ---
    // Espera o flash começar a sumir (300ms) e coloca a foto na mira
    setTimeout(function() {
        const mira = document.getElementById("mira-foto");
        if (mira) {
            const foto = document.createElement("img");
            // A sua foto aqui
            foto.src = "imagem/agente_genérico.png"; 
            
            foto.style.width = "100%";
            foto.style.height = "100%";
            foto.style.objectFit = "cover";
            foto.style.borderRadius = "8px";
            
            // Efeito de aparição (começa invisível e surge)
            foto.style.opacity = "0";
            foto.style.transition = "opacity 0.5s ease";
            foto.style.filter = "grayscale(100%) contrast(1.5)";

            mira.appendChild(foto);

            // Força o navegador a mostrar a foto (fade-in)
            setTimeout(function() {
                foto.style.opacity = "0.8";
            }, 50);
        }
    }, 300);

    // Efeito sonoro opcional (bipe curtinho)
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = 1200;
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
        osc.start();
        osc.stop(ctx.currentTime + 0.15);
    } catch (e) {
        // se o navegador bloquear, ignora
    }

    setTimeout(function () {
        flash.remove();
    }, 700);
}

// ==============================
// FUNDO ANIMADO DA ORDO (SELOS)
// ==============================
function criarSelosFundo() {
    const fundo = document.getElementById("fundo-selos");
    if (!fundo) return;

    // Lista com os caminhos das imagens dos selos
    const imagensSelos = [
        "imagem/selo1.png", // vermelho
        "imagem/selo2.png", // cinza
        "imagem/selo3.png", // preto
        "imagem/selo4.png", // roxo
        "imagem/selo5.png", //amarelo
      
    ];

    // Cria 15 selos flutuantes
    for (let i = 0; i < 15; i++) {
        const selo = document.createElement("img");
        
        // Sorteia qual selo vai ser
        const imagemSorteada = imagensSelos[Math.floor(Math.random() * imagensSelos.length)];
        selo.src = imagemSorteada;
        selo.className = "selo-flutuante";
    
        //se a imagem nao carregar, avise no console (ajuda a acha o erro)
        selo.onerror = function() {
            console.log("❌ erro: não achei imagem" + imagemSorteada + "confira o nome e a extensão!");
        };

        // Posição horizontal aleatória
        selo.style.left = Math.random() * 100 + "%";

        // Tamanho aleatório (entre 40px e 100px)
        const tamanho = 40 + Math.random() * 60;
        selo.style.width = tamanho + "px";
        selo.style.height = tamanho + "px";

        // Tempo de animação aleatório (entre 10s e 25s)
        const duracao = 10 + Math.random() * 15;
        selo.style.animationDuration = duracao + "s";

        // Atraso aleatório para não subirem todos juntos
        const atraso = Math.random() * 15;
        selo.style.animationDelay = atraso + "s";

        fundo.appendChild(selo);
    }
}

// Chama a função assim que o site carregar
criarSelosFundo();

// ==============================
// EFEITO MÁQUINA DE ESCREVER (ORDO)
// ==============================
function iniciarEfeitoDigitacao() {
    const elemento = document.getElementById("texto-terminal");
    if (!elemento) return;

    // Zera o texto sempre que a tela for acessada
    elemento.textContent = "";

    // Na função iniciarEfeitoDigitacao
    const textoCompleto = "Você encontrou um canal de comunicação restrito. O acesso não autorizado, você está sendo monitorado.";
    let index = 0;

    function digitar() {
    if (index < textoCompleto.length) {
        elemento.textContent += textoCompleto.charAt(index);
        index++;
        tocarSom('digitando'); // <--- ADICIONE AQUI
        setTimeout(digitar, 50); 
    }
}
  
    // Começa a digitar depois de 500ms (meio segundo) para dar tempo da tela abrir
    setTimeout(digitar, 500);
}

// Chama o efeito quando a tela da Ordo for exibida
// Vamos "enganchar" isso na sua função mostrarTela
const mostrarTelaOriginal = mostrarTela;
mostrarTela = function(idTela) {
    mostrarTelaOriginal(idTela);
    if (idTela === "tela-ordo") {
        iniciarEfeitoDigitacao();
    }
};

// ==============================
// SCANNER BIOMÉTRICO (CENTRAL)
// ==============================
function iniciarScannerBiometrico() {
    // Configurações iniciais
    document.getElementById("tela-scanner").hidden = false;
    document.getElementById("form-agente").hidden = true;
    
    const status = document.getElementById("status-scanner");
    const barra = document.getElementById("progresso-scanner");
    const camera = document.querySelector(".scanner-camera");
    
    // Zera a barra
    barra.style.width = "0%";
    status.textContent = "Iniciando varredura facial...";
    
    // Remove flash antigo se houver
    const flashAntigo = document.querySelector(".flash-scanner");
    if (flashAntigo) flashAntigo.remove();

    let progresso = 0;
    
    // Animação da barra e troca de textos
    const intervalo = setInterval(function() {
        progresso += 2; 
        barra.style.width = progresso + "%";
    
        // Toca um som baixinho a cada 10% de progresso
        if (progresso % 10 === 0) tocarSom('scanner'); // <--- ADICIONE AQUI

        if (progresso >= 100) {
            clearInterval(intervalo);
            tocarSom('sucesso'); // <--- ADICIONE AQUI
        
            // Efeito de Flash (Foto tirada)
            const flash = document.createElement("div");
            flash.className = "flash-scanner";
            camera.appendChild(flash);
            
            // Toca um bipe de confirmação
            try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.connect(gain); gain.connect(ctx.destination);
                osc.frequency.value = 1500;
                gain.gain.setValueAtTime(0.1, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
                osc.start(); osc.stop(ctx.currentTime + 0.2);
            } catch(e) {}

            // Vibra o celular
            if (navigator.vibrate) navigator.vibrate([100, 50, 100]);

            // Troca de tela após o flash
            setTimeout(function() {
                document.getElementById("tela-scanner").hidden = true;
                document.getElementById("form-agente").hidden = false;
                
                // Foca no input do agente pra facilitar a vida do jogador
                document.getElementById("numero-agente").focus();
            }, 600); // Espera o flash terminar
        }
    }, 40); // Velocidade do scanner (40ms * 50 = ~2 segundos)
}

// Engancha a função no botão de acessar comunicação
// ATENÇÃO: Remova o listener antigo do "acessar-comunicacao" que tínhamos no mapa "acoesBotoes" se ele ainda estiver lá.
// Se você manteve o mapa "acoesBotoes", apenas substitua a ação dele no mapa por: "acessar-comunicacao": iniciarScannerBiometrico

// Como o seu código antigo usa "acoesBotoes", a forma mais fácil e limpa é reescrever o botão:
const btnAcessar = document.getElementById("acessar-comunicacao");
if (btnAcessar) {
    // Remove ouvintes antigos clonando o botão (jeito mais seguro sem quebrar o resto)
    const btnNovo = btnAcessar.cloneNode(true);
    btnAcessar.parentNode.replaceChild(btnNovo, btnAcessar);
    
    // Adiciona a nova ação
    btnNovo.addEventListener("click", function() {
        mostrarTela("central-comunicacao");
        iniciarScannerBiometrico();
    });
}

// ==============================
// EFEITO MATRIX (FUNDO DO FORMULÁRIO)
// ==============================
function iniciarMatrix() {
    const canvas = document.getElementById("matrix-ordo");
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    
    // Ajusta o canvas pro tamanho da tela
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*アカサタナハマヤラワ";
    const tamanhoFonte = 14;
    const colunas = canvas.width / tamanhoFonte;
    const arrayQueda = [];

    for (let i = 0; i < colunas; i++) {
        arrayQueda[i] = 1;
    }

    function desenhar() {
        // Fundo preto com opacidade (deixa o rastro)
        ctx.fillStyle = "rgba(10, 11, 14, 0.1)";
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = "#c43b3b"; // Cor vermelha da Ordem
        ctx.font = tamanhoFonte + "px monospace";

        for (let i = 0; i < arrayQueda.length; i++) {
            const texto = letras.charAt(Math.floor(Math.random() * letras.length));
            ctx.fillText(texto, i * tamanhoFonte, arrayQueda[i] * tamanhoFonte);

            // Se passar do chão, volta pro topo (aleatório)
            if (arrayQueda[i] * tamanhoFonte > canvas.height && Math.random() > 0.975) {
                arrayQueda[i] = 0;
            }
            arrayQueda[i]++;
        }
    }
    
    // Salva o intervalo na memória pra parar depois se precisar
    if (window.matrixInterval) clearInterval(window.matrixInterval);
    window.matrixInterval = setInterval(desenhar, 50);
}

// ==============================
// LÓGICA DO AGENTE (ATUALIZADA)
// ==============================
// Precisamos substituir a função antiga do consultar-agente para adicionar o Matrix
const btnConsultar = document.getElementById("consultar-agente");
if (btnConsultar) {
    // Clona o botão pra remover o evento antigo
    const novoBtn = btnConsultar.cloneNode(true);
    btnConsultar.parentNode.replaceChild(novoBtn, btnConsultar);

    novoBtn.addEventListener("click", function () {
        const numero = document.getElementById("numero-agente").value.trim().toUpperCase();
        const resultadoAgente = document.getElementById("resultado-agente");

        // Efeito sonoro de computador
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            osc.type = "square";
            osc.frequency.value = 800;
            osc.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.1);
        } catch (e) {}

        if (numero === "0724-OR") {
    resultadoAgente.style.color = "#36c310";
    resultadoAgente.textContent = "ACESSO CONCEDIDO. CARREGANDO DOSSIÊ...";
    
    setTimeout(function () {
        resultadoAgente.textContent = "";
        resultadoAgente.style.color = "#ff4444"; 
        mostrarTela("confirmacao-agente"); 
        iniciarBuscaAgente(); // <--- ADICIONE ESSA LINHA AQUI
    }, 1200);

        } else {
            resultadoAgente.style.color = "#ff4444";
            resultadoAgente.textContent = "ERRO 404: AGENTE NÃO LOCALIZADO NO BANCO DE DADOS.";
            
            // Efeito de erro (vibra 2 vezes)
            if (navigator.vibrate) navigator.vibrate([50, 50, 50]);
        }
    });
}

// Atualiza o resize da tela pra não bugar o Matrix no celular
window.addEventListener("resize", function() {
    const canvas = document.getElementById("matrix-ordo");
    if (canvas && !document.getElementById("form-agente").hidden) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
});

// ==============================
// ANIMAÇÃO DE BUSCA DE AGENTE
// ==============================
function iniciarBuscaAgente() {
    const telaBusca = document.getElementById("tela-busca-agente");
    const telaResultado = document.getElementById("resultado-busca-agente");
    const numeroAleatorio = document.getElementById("numero-aleatorio");
    const statusBusca = document.getElementById("status-busca");
    const caixaNumero = document.getElementById("caixa-numero-busca");

    // Reseta o estado inicial
    telaBusca.hidden = false;
    telaResultado.hidden = true;
    caixaNumero.classList.remove("encontrado");
    statusBusca.textContent = "Acessando banco de dados...";
    
    let tempoDecorrido = 0;
    const tempoTotal = 4000; // 4 segundos de suspense

    // --- SOM CONTÍNUO DE BUSCA (Estilo Matrix) ---
    let somBuscaCtx, somBuscaOsc;
    try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        somBuscaCtx = new AudioCtx();
        somBuscaOsc = somBuscaCtx.createOscillator();
        const gain = somBuscaCtx.createGain();
        
        somBuscaOsc.type = 'sawtooth'; // Som mais robótico
        somBuscaOsc.frequency.setValueAtTime(100, somBuscaCtx.currentTime); // Começa grave
        
        // Faz o som oscilar (subir e descer rápido)
        somBuscaOsc.frequency.linearRampToValueAtTime(200, somBuscaCtx.currentTime + 0.2);
        somBuscaOsc.frequency.linearRampToValueAtTime(100, somBuscaCtx.currentTime + 0.4);
        
        gain.gain.setValueAtTime(0.03, somBuscaCtx.currentTime); // Volume baixinho pra não estourar
        
        somBuscaOsc.connect(gain);
        gain.connect(somBuscaCtx.destination);
        somBuscaOsc.start();
    } catch(e) {
        console.log("Áudio bloqueado");
    }

    // Função que gera os números aleatórios
    function gerarNumeroAleatorio() {
        const num1 = Math.floor(Math.random() * 9000) + 1000;
        const num2 = Math.floor(Math.random() * 99);
        const letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const letra = letras.charAt(Math.floor(Math.random() * letras.length));
        
        numeroAleatorio.textContent = `${num1}-${letra}${num2}`;
    }

    // Roda a geração de números rápido
    const intervaloNumeros = setInterval(gerarNumeroAleatorio, 50);

    // Muda o texto de status durante a busca
    const intervaloStatus = setInterval(function() {
        tempoDecorrido += 500;
        if (tempoDecorrido === 1000) statusBusca.textContent = "Lendo arquivos confidenciais...";
        if (tempoDecorrido === 2000) statusBusca.textContent = "Cruzando dados de agentes...";
        if (tempoDecorrido === 3000) statusBusca.textContent = "Registro localizado!";
    }, 500);

    // Depois do tempo, trava no número certo!
    setTimeout(function() {
        clearInterval(intervaloNumeros);
        clearInterval(intervaloStatus);
        
        // Para o som contínuo
        if (somBuscaOsc) {
            try { somBuscaOsc.stop(); } catch(e) {}
        }
        
        // Trava no 0724-OR
        numeroAleatorio.textContent = "0724-OR";
        statusBusca.textContent = "Registro localizado!";
        
        // Efeito visual de sucesso
        caixaNumero.classList.add("encontrado");
        
        // Toca o som de confirmação (Bip agudo de sucesso)
        tocarSom('sucesso');
        
        if (navigator.vibrate) navigator.vibrate([100, 50, 100]);

        // Esconde a busca e mostra o resultado final
        setTimeout(function() {
            telaBusca.hidden = true;
            telaResultado.hidden = false;
            
            // Garante que começa sem a classe verde
            telaResultado.classList.remove("liberado");

            // --- ETAPA VERMELHA ---
            setTimeout(function() {
                const h1 = telaResultado.querySelector("h1");
                const p = telaResultado.querySelector("p");
                
                h1.innerHTML = "IDENTIFICAÇÃO<br>CONFIRMADA";
                p.textContent = "Agente reconhecido pelo sistema";

                // --- ETAPA VERDE ---
                setTimeout(function() {
                    telaResultado.classList.add("liberado");
                    tocarSom('sucesso');
                    
                    if (navigator.vibrate) navigator.vibrate([100, 50, 100]);

                    // Espera 1.5 segundos curtindo a tela verde e pula pro dossiê
                    setTimeout(function() {
                        document.getElementById("confirmacao-agente").hidden = true;
                        mostrarTela("dossie-agente");
                    }, 1500);

                }, 500);
            }, 1000);
        }, 1500);
    }, tempoTotal);
}

// ==============================
// SISTEMA DE ÁUDIO DA ORDO
// ==============================
const AudioContext = window.AudioContext || window.webkitAudioContext;
let audioCtx;

function tocarSom(tipo) {
    try {
        if (!audioCtx) audioCtx = new AudioContext();
        // Se o áudio estiver suspenso (bloqueio do navegador), a gente acorda ele
        if (audioCtx.state === 'suspended') audioCtx.resume();

        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);

        if (tipo === 'digitando') {
           // Simula o som de máquina de escrever (tecla batendo + retorno do carro)
    
           // 1. O "TEC" da tecla (um estalo rápido)
           const oscTec = audioCtx.createOscillator();
           const gainTec = audioCtx.createGain();
           oscTec.type = 'triangle'; // Um som mais metálico
           oscTec.frequency.setValueAtTime(800 + Math.random() * 400, audioCtx.currentTime); 
           oscTec.frequency.exponentialRampToValueAtTime(100, audioCtx.currentTime + 0.02); 
    
           gainTec.gain.setValueAtTime(0.1, audioCtx.currentTime);
           gainTec.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.03); 
    
           oscTec.connect(gainTec);
           gainTec.connect(audioCtx.destination);
           oscTec.start(); 
           oscTec.stop(audioCtx.currentTime + 0.03);

           // 2. O barulho de "ruído" (o papel/mecanismo)
           const bufferSize = audioCtx.sampleRate * 0.02; 
           const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
           const data = buffer.getChannelData(0);
           for (let i = 0; i < bufferSize; i++) {
              data[i] = Math.random() * 2 - 1; // Cria um ruído branco
           }
           const noise = audioCtx.createBufferSource();
           noise.buffer = buffer;
           const gainNoise = audioCtx.createGain();
           gainNoise.gain.setValueAtTime(0.05, audioCtx.currentTime);
           gainNoise.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.02);
    
           noise.connect(gainNoise);
           gainNoise.connect(audioCtx.destination);
           noise.start();
        } 
        else if (tipo === 'numero') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, audioCtx.currentTime); // Som de processamento
            gain.gain.setValueAtTime(0.01, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);
            osc.start(); osc.stop(audioCtx.currentTime + 0.05);
        }
        else if (tipo === 'scanner') {
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(200, audioCtx.currentTime);
            osc.frequency.linearRampToValueAtTime(1000, audioCtx.currentTime + 0.5); // Sobe o tom
            gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.5);
            osc.start(); osc.stop(audioCtx.currentTime + 0.5);
        }
        else if (tipo === 'sucesso') {
            osc.type = 'sine';
            osc.frequency.setValueAtTime(800, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(1200, audioCtx.currentTime + 0.1);
            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
            osc.start(); osc.stop(audioCtx.currentTime + 0.3);
        }
        else if (tipo === 'flash') {
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(1500, audioCtx.currentTime);
            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
            osc.start(); osc.stop(audioCtx.currentTime + 0.2);
        }
    } catch(e) {
        console.log("Áudio bloqueado pelo navegador");
    }
}

// ==============================
// SISTEMA DE EXPULSÃO E ERRO
// ==============================
const btnTentarAcesso = document.getElementById("btn-tentar-acesso");
const telaErroSistema = document.getElementById("tela-erro-sistema");
const btnForcarAcesso = document.getElementById("btn-forcar-acesso");

// Abre a tela de erro
if (btnTentarAcesso) {
    btnTentarAcesso.addEventListener("click", function() {
        tocarSom('erro'); // Toca som se tiver
        telaErroSistema.hidden = false;
    });
}

// Bug de tela e Expulsão
if (btnForcarAcesso) {
    btnForcarAcesso.addEventListener("click", function() {
        
        // 1. Toca um som de erro esquisito
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const osc = ctx.createOscillator();
            osc.type = "sawtooth";
            osc.frequency.setValueAtTime(100, ctx.currentTime);
            osc.frequency.linearRampToValueAtTime(50, ctx.currentTime + 1);
            osc.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 1);
        } catch(e) {}

        // 2. Aplica o Efeito Bug na Tela
        document.body.classList.add("tela-bugada");
        
        if (navigator.vibrate) navigator.vibrate([200, 100, 200, 100, 500]);

        // 3. Espera 1.5 segundos (tempo do bug) e reseta tudo
        setTimeout(function() {
            // Tira o bug
            document.body.classList.remove("tela-bugada");
            
            // Esconde a tela de erro
            telaErroSistema.hidden = true;

            // Esconde todas as telas da Ordo
            esconderTodasTelasOrdo();

            // Volta para o site de receitas
            document.querySelector("header").hidden = false;
            document.querySelector("main").hidden = false;
            
            // Limpa a barra de pesquisa
            pesquisa.value = "";
            resultado.textContent = "";
            filtrarReceitas(); // Reseta os cards

            // Cria o aviso de expulsão no topo
            const aviso = document.createElement("div");
            aviso.id = "aviso-expulsao";
            aviso.innerHTML = "⚠️ ACESSO NEGADO. TENTATIVA DE INVASÃO DETECTADA. VOCÊ FOI EXPULSO. ⚠️";
            document.body.appendChild(aviso);

            // Toca um som de "queda de energia"
            try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const osc = ctx.createOscillator();
                osc.type = "square";
                osc.frequency.setValueAtTime(300, ctx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(50, ctx.currentTime + 0.5);
                osc.connect(ctx.destination);
                osc.start();
                osc.stop(ctx.currentTime + 0.5);
            } catch(e) {}

            // Remove o aviso depois de 5 segundos
            setTimeout(function() {
                if (aviso) {
                    aviso.style.transition = "opacity 0.5s";
                    aviso.style.opacity = "0";
                    setTimeout(() => aviso.remove(), 500);
                }
            }, 5000);

        }, 1500); // Tempo que a tela fica bugada
    });
}